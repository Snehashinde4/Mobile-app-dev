import 'package:flutter/material.dart';

void main() {
  runApp(ElderCareApp());
}

class ElderCareApp extends StatefulWidget {
  @override
  State<ElderCareApp> createState() => _ElderCareAppState();
}

class _ElderCareAppState extends State<ElderCareApp> {
  bool _showLanding = true;

  void _onGetStarted() {
    setState(() {
      _showLanding = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Elder Care',
      theme: ThemeData(
        primaryColor: Color(0xFFB497D6),
        scaffoldBackgroundColor: Color(0xFFEDE7F6), // Soft lavender
        fontFamily: 'Roboto',
        textTheme: Theme.of(context).textTheme.apply(
          bodyColor: Colors.deepPurple[900],
          displayColor: Colors.deepPurple[900],
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: _showLanding
          ? LavenderLandingPage(onGetStarted: _onGetStarted)
          : MainScreen(),
    );
  }
}

//------------------- LAVENDER LANDING PAGE -------------------
class LavenderLandingPage extends StatelessWidget {
  final VoidCallback onGetStarted;
  const LavenderLandingPage({Key? key, required this.onGetStarted}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final lavender = Color(0xFFE6E6FA);
    final deepLavender = Color(0xFFB497D6);

    return Scaffold(
      backgroundColor: lavender,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Simple icon with subtle shadow
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: deepLavender.withOpacity(0.18),
                      blurRadius: 16,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                padding: EdgeInsets.all(36),
                child: Icon(
                  Icons.spa,
                  size: 72,
                  color: deepLavender,
                ),
              ),
              SizedBox(height: 40),
              Text(
                'Welcome to Elder Care',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple[800],
                  letterSpacing: 1,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Gentle support for your health and happiness.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.deepPurple[400],
                  height: 1.4,
                ),
              ),
              SizedBox(height: 56),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: onGetStarted,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: deepLavender,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                    elevation: 3,
                  ),
                  child: Text(
                    'Get Started',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//------------------- MAIN SCREEN -------------------
class MainScreen extends StatefulWidget {
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  final MedicationScreen _medicationScreen = MedicationScreen();
  final AppointmentScreen _appointmentScreen = AppointmentScreen();

  List<Widget> get _screens => [
    HomeScreen(onNavigate: (int index) {
      setState(() {
        _selectedIndex = index;
      });
    }),
    _medicationScreen,
    _appointmentScreen,
    ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFFB497D6),
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
        iconSize: 28,
        selectedFontSize: 16,
        unselectedFontSize: 14,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.medication), label: 'Meds'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Appts'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

//------------------- HOME SCREEN -------------------
class HomeScreen extends StatelessWidget {
  final Function(int)? onNavigate;
  HomeScreen({this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final greeting = TimeOfDay.now().hour < 12
        ? 'Good Morning'
        : (TimeOfDay.now().hour < 18 ? 'Good Afternoon' : 'Good Evening');
    final cardColor = Color(0xFFF3E8FF);

    return Container(
      color: Color(0xFFEDE7F6),
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(24),
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 40, color: Color(0xFFB497D6)),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Text(
                    '$greeting,\n ABC! ❤',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF7B68EE),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.help_outline, color: Color(0xFF7B68EE)),
                  tooltip: 'Need Help?',
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text('How to use'),
                        content: Text(
                            'Tap the navigation bar below to access medication reminders, appointments, or your profile.'),
                        actions: [
                          TextButton(
                            child: Text('OK'),
                            onPressed: () => Navigator.pop(context),
                          )
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 28),
            Card(
              color: cardColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              elevation: 7,
              child: ListTile(
                leading: Icon(Icons.medication, color: Color(0xFFB497D6), size: 36),
                title: Text('Medication Reminders', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFF4B3F72))),
                subtitle: Text('View and manage your daily medications.', style: TextStyle(color: Color(0xFF7B68EE))),
                trailing: Icon(Icons.arrow_forward_ios, color: Color(0xFF7B68EE)),
                onTap: () {
                  if (onNavigate != null) onNavigate!(1);
                },
              ),
            ),
            SizedBox(height: 18),
            Card(
              color: cardColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              elevation: 7,
              child: ListTile(
                leading: Icon(Icons.calendar_today, color: Color(0xFFB497D6), size: 36),
                title: Text('Appointments', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFF4B3F72))),
                subtitle: Text('Check your upcoming appointments.', style: TextStyle(color: Color(0xFF7B68EE))),
                trailing: Icon(Icons.arrow_forward_ios, color: Color(0xFF7B68EE)),
                onTap: () {
                  if (onNavigate != null) onNavigate!(2);
                },
              ),
            ),
            SizedBox(height: 18),
            Card(
              color: Colors.pink[100],
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              elevation: 7,
              child: ListTile(
                leading: Icon(Icons.health_and_safety, color: Colors.pink[400], size: 36),
                title: Text('EMERGENCY', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.pink[800])),
                subtitle: Text('Send an alert to your emergency contact.', style: TextStyle(color: Colors.pink[400])),
                trailing: Icon(Icons.warning_amber_rounded, color: Colors.pink[400]),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: Text('Emergency!'),
                      content: Text('Your emergency contact has been notified.'),
                      actions: [
                        TextButton(
                          child: Text('OK'),
                          onPressed: () => Navigator.pop(context),
                        )
                      ],
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 28),
            Text('How are you feeling today?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Color(0xFF4B3F72))),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _MoodEmoji(emoji: '😊', label: 'Good'),
                _MoodEmoji(emoji: '😐', label: 'Okay'),
                _MoodEmoji(emoji: '😔', label: 'Sad'),
                _MoodEmoji(emoji: '😷', label: 'Unwell'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MoodEmoji extends StatelessWidget {
  final String emoji;
  final String label;
  const _MoodEmoji({required this.emoji, required this.label});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(emoji, style: TextStyle(fontSize: 36)),
        SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 14, color: Color(0xFF7B68EE))),
      ],
    );
  }
}

//------------------- MEDICATION SCREEN -------------------
class MedicationScreen extends StatefulWidget {
  @override
  _MedicationScreenState createState() => _MedicationScreenState();
}

class _MedicationScreenState extends State<MedicationScreen> {
  final List<Map<String, dynamic>> _reminders = [];
  final TextEditingController _medicineController = TextEditingController();

  Future<void> _showAddReminderDialog() async {
    TimeOfDay? pickedTime;
    String medicineName = "";

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              backgroundColor: Color(0xFFE6E6FA),
              title: Text('Add Medicine Reminder', style: TextStyle(color: Color(0xFF7B68EE))),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: _medicineController,
                    decoration: InputDecoration(
                      labelText: 'Medicine Name',
                      labelStyle: TextStyle(color: Color(0xFF7B68EE)),
                      border: OutlineInputBorder(),
                    ),
                    style: TextStyle(color: Color(0xFF4B3F72)),
                    onChanged: (value) {
                      medicineName = value;
                    },
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Text(
                        pickedTime == null
                            ? 'Pick Time'
                            : 'Time: ${pickedTime!.format(context)}',
                        style: TextStyle(fontSize: 16, color: Color(0xFF7B68EE)),
                      ),
                      Spacer(),
                      IconButton(
                        icon: Icon(Icons.access_time, color: Color(0xFFB497D6)),
                        onPressed: () async {
                          TimeOfDay? time = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.now(),
                          );
                          if (time != null) {
                            setStateDialog(() {
                              pickedTime = time;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  child: Text('Cancel', style: TextStyle(color: Color(0xFF7B68EE))),
                  onPressed: () {
                    _medicineController.clear();
                    Navigator.of(context).pop();
                  },
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFB497D6),
                  ),
                  child: Text('Add', style: TextStyle(color: Colors.white)),
                  onPressed: () {
                    if (_medicineController.text.isNotEmpty &&
                        pickedTime != null) {
                      setState(() {
                        _reminders.add({
                          'medicine': _medicineController.text,
                          'time': pickedTime,
                        });
                        _medicineController.clear();
                      });
                      Navigator.of(context).pop();
                    }
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _deleteReminder(int index) {
    setState(() {
      _reminders.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medication Reminders', style: TextStyle(color: Color(0xFF7B68EE))),
        backgroundColor: Color(0xFFE6E6FA),
        iconTheme: IconThemeData(color: Color(0xFF7B68EE)),
        elevation: 1,
      ),
      body: Container(
        color: Color(0xFFEDE7F6),
        child: _reminders.isEmpty
            ? Center(
          child: Text(
            'No reminders yet.\nTap + to add one!',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, color: Color(0xFFB497D6)),
          ),
        )
            : ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: _reminders.length,
          itemBuilder: (context, index) {
            final reminder = _reminders[index];
            return Card(
              color: Color(0xFFF3E8FF),
              margin: EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: Icon(Icons.medication, color: Color(0xFFB497D6), size: 32),
                title: Text(reminder['medicine'],
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFF4B3F72))),
                subtitle: Text(
                  'Time: ${reminder['time'].format(context)}',
                  style: TextStyle(fontSize: 16, color: Color(0xFF7B68EE)),
                ),
                trailing: IconButton(
                  icon: Icon(Icons.delete, color: Colors.pink[400]),
                  onPressed: () => _deleteReminder(index),
                  tooltip: 'Delete',
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddReminderDialog,
        tooltip: 'Add Reminder',
        backgroundColor: Color(0xFFB497D6),
        child: Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

//------------------- APPOINTMENT SCREEN -------------------
class AppointmentScreen extends StatelessWidget {
  final List<Map<String, String>> appointments = [
    {'doctor': 'Dr. Smith', 'date': '2025-05-20', 'time': '10:00 AM'},
    {'doctor': 'Dr. Lee', 'date': '2025-05-22', 'time': '2:00 PM'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appointments', style: TextStyle(color: Color(0xFF7B68EE))),
        backgroundColor: Color(0xFFE6E6FA),
        iconTheme: IconThemeData(color: Color(0xFF7B68EE)),
        elevation: 1,
      ),
      body: Container(
        color: Color(0xFFEDE7F6),
        child: ListView.builder(
          itemCount: appointments.length,
          padding: EdgeInsets.all(16),
          itemBuilder: (context, index) {
            final appt = appointments[index];
            return Card(
              color: Color(0xFFF3E8FF),
              margin: EdgeInsets.symmetric(vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: Icon(Icons.calendar_today, color: Color(0xFFB497D6), size: 32),
                title: Text('${appt['doctor']}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFF4B3F72))),
                subtitle: Text('${appt['date']} at ${appt['time']}', style: TextStyle(color: Color(0xFF7B68EE))),
                trailing: Icon(Icons.arrow_forward_ios, color: Color(0xFF7B68EE)),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Add Appointment',
        backgroundColor: Color(0xFFB497D6),
        child: Icon(Icons.add, color: Colors.white),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Add Appointment feature coming soon!')),
          );
        },
      ),
    );
  }
}

//------------------- PROFILE SCREEN -------------------
class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Profile', style: TextStyle(color: Color(0xFF7B68EE))),
        backgroundColor: Color(0xFFE6E6FA),
        iconTheme: IconThemeData(color: Color(0xFF7B68EE)),
        elevation: 1,
      ),
      body: Container(
        color: Color(0xFFEDE7F6),
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            CircleAvatar(
              radius: 48,
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 60, color: Color(0xFFB497D6)),
            ),
            SizedBox(height: 16),
            Text('John Doe', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF4B3F72))),
            Text('Age: 72', style: TextStyle(fontSize: 18, color: Color(0xFF7B68EE))),
            SizedBox(height: 24),
            Card(
              color: Color(0xFFF3E8FF),
              elevation: 6,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: Icon(Icons.phone, color: Color(0xFFB497D6)),
                title: Text('Emergency Contact', style: TextStyle(color: Color(0xFF4B3F72))),
                subtitle: Text('+91 9876543210', style: TextStyle(color: Color(0xFF7B68EE))),
                trailing: Icon(Icons.edit, color: Color(0xFFB497D6)),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Edit Contact feature coming soon!')),
                  );
                },
              ),
            ),
            SizedBox(height: 18),
            Card(
              color: Color(0xFFF3E8FF),
              elevation: 6,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: ListTile(
                leading: Icon(Icons.settings, color: Color(0xFFB497D6)),
                title: Text('Settings', style: TextStyle(color: Color(0xFF4B3F72))),
                trailing: Icon(Icons.arrow_forward_ios, color: Color(0xFFB497D6)),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Settings feature coming soon!')),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
